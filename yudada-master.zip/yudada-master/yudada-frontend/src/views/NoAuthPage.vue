<template>
  <div id="noAuthPage">无权限</div>
</template>

<script setup lang="ts"></script>
