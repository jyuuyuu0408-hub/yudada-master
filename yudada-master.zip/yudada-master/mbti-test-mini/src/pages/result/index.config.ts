export default definePageConfig({
  navigationBarTitleText: '查看结果'
})
